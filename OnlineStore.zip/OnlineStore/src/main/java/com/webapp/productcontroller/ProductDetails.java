package com.webapp.productcontroller;

public class ProductDetails {

	private String productdetls;

	public String getProductdetls() {
		return productdetls;
	}

	public void setProductdetls(String productdetls) {
		this.productdetls = productdetls;
	}
}
