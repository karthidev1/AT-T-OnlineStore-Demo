package com.webapp.productcontroller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SessionAttributes("userName")
@EnableWebMvc
@Controller
public class ProductController {
	
	@Autowired
	private UserDetails detls;
	
	
	@RequestMapping(value="/login",method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getAdmissionForm(){
		
		ModelAndView model = new ModelAndView("LoginPage");
		return model;
		
	}
	
	@RequestMapping(value="/submitLoginForm.html",method=RequestMethod.POST)
	public ModelAndView submitLoginForm(@RequestParam("userName") String user, @RequestParam("password") String pwd){
		
		if(detls.getUserName().contains(user)&& detls.getPassword().contains(pwd)){
			
			ModelAndView modelHomePage = new ModelAndView("HomePage");
			modelHomePage.addObject("userName", user);
			return modelHomePage;
		}	
		ModelAndView modelErrorPage = new ModelAndView("ErrorPage");
		return modelErrorPage;
		
	}
	
}
