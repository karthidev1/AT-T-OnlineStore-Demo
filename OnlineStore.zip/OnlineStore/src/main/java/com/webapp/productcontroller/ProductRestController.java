package com.webapp.productcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;

@SessionAttributes("userName")
@RestController
public class ProductRestController {
	
	@Autowired
	private ProductService productService;
	
	@RequestMapping(value="/products",produces="application/json")
	@ResponseBody
	public List<Product> getAllProducts() {
		 return productService.getProducts();
	}
	

	@RequestMapping(value="/products/add",method=RequestMethod.POST,consumes="application/json")
	@ResponseBody
	public void addProduct(@RequestBody Product product) {
		
		productService.addProduct(product);
	}
	
	@RequestMapping(value="/products/{id}",method = RequestMethod.PUT )
	@ResponseBody
	public void updateProduct(@PathVariable int id, @RequestBody Product product) {
		productService.updateProduct(id, product);
	}
	
	@RequestMapping( value="/products/{id}",method = RequestMethod.DELETE)
	@ResponseBody
	public void deleteProduct(@PathVariable int id) {
		productService.removeProduct(id);
	}
	
	
}
