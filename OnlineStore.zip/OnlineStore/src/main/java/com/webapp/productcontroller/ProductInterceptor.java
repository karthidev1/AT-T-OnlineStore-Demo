package com.webapp.productcontroller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.WebUtils;

public class ProductInterceptor extends HandlerInterceptorAdapter {
	public boolean preHandle(HttpServletRequest request,
	            HttpServletResponse response, Object handler) throws Exception {
		
		String user = (String) WebUtils.getSessionAttribute(request, "userName");

		System.out.println("Hit interceptor:::::" + user);

		if (user != null) {

			return true;
			
		} else {

			System.out.println("Hit interceptor inside!!!!");

			response.setStatus(404);

			return false;

		}

	}
}


